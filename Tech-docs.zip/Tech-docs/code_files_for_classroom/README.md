# Malaysia Banking AI/ML Training Pack

This pack contains:
- `data/malaysia_banking_customers_500.csv` — 10 columns, 500 rows, Malaysian banking customer dataset.
- `notebooks/01_pandas_100_tasks_only.ipynb` — 100 markdown-only pandas tasks.
- `notebooks/02_pandas_100_tasks_with_solutions.ipynb` — 100 tasks with runnable solution cells.
- `notebooks/03_ml_linear_regression_account_balance.ipynb` — step-by-step regression model.
- `notebooks/04_ml_logistic_regression_default_prediction.ipynb` — step-by-step classification model.
- `notebooks/05_genai_banking_usecases_prompts.ipynb` — GenAI use cases and prompts.
- `notebooks/06_langchain_openai_banking_examples.ipynb` — LangChain OpenAI examples.
- `notebooks/07_rag_implementation_multi_source_langchain.ipynb` — RAG using PDF, TXT, CSV loaders.
- `notebooks/08_rag_implementation_offline_tfidf.ipynb` — second RAG-style offline implementation.
- `rag_docs/` — sample banking PDFs, TXT, and CSV for RAG data loading.

Suggested path: open notebooks from the `notebooks` folder so relative paths work correctly.

## Latest Updated Notebooks

- `09_basic_nlp_nltk_sentiment_analysis.ipynb` — simplified beginner NLTK sentiment analysis.
- `10_banking_dataset_summarization.ipynb` — LangChain OpenAI summarization with meaningful banking prompts.
- `11_customer_segmentation_kmeans.ipynb` — replaced with LangChain OpenAI customer segmentation use case and prompts.
- `13_langchain_openai_prompt_engineering_banking_examples.ipynb` — final prompt engineering notebook with multiple prompt types.


## Simple LangChain style update
The LangChain OpenAI notebooks now avoid `ChatPromptTemplate.from_template` and the `|` chain operator. They use direct `llm.invoke(prompt)` calls for beginner-friendly classroom delivery.
